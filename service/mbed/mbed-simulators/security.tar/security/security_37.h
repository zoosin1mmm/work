/*
 * Copyright (c) 2015 ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef __SECURITY_H__
#define __SECURITY_H__
 
#include <inttypes.h>
 
#define MBED_DOMAIN "d32baf61-4845-4ae7-bf0c-3b0b2c8db2e4"
#define MBED_ENDPOINT_NAME "e7ef29e0-9458-47af-8c2f-c3fd8f87682c"
 
const uint8_t SERVER_CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBmDCCAT6gAwIBAgIEVUCA0jAKBggqhkjOPQQDAjBLMQswCQYDVQQGEwJGSTEN\r\n"
"MAsGA1UEBwwET3VsdTEMMAoGA1UECgwDQVJNMQwwCgYDVQQLDANJb1QxETAPBgNV\r\n"
"BAMMCEFSTSBtYmVkMB4XDTE1MDQyOTA2NTc0OFoXDTE4MDQyOTA2NTc0OFowSzEL\r\n"
"MAkGA1UEBhMCRkkxDTALBgNVBAcMBE91bHUxDDAKBgNVBAoMA0FSTTEMMAoGA1UE\r\n"
"CwwDSW9UMREwDwYDVQQDDAhBUk0gbWJlZDBZMBMGByqGSM49AgEGCCqGSM49AwEH\r\n"
"A0IABLuAyLSk0mA3awgFR5mw2RHth47tRUO44q/RdzFZnLsAsd18Esxd5LCpcT9w\r\n"
"0tvNfBv4xJxGw0wcYrPDDb8/rjujEDAOMAwGA1UdEwQFMAMBAf8wCgYIKoZIzj0E\r\n"
"AwIDSAAwRQIhAPAonEAkwixlJiyYRQQWpXtkMZax+VlEiS201BG0PpAzAiBh2RsD\r\n"
"NxLKWwf4O7D6JasGBYf9+ZLwl0iaRjTjytO+Kw==\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBzzCCAXOgAwIBAgIEULMOhTAMBggqhkjOPQQDAgUAMDkxCzAJBgNVBAYTAkZ\r\n"
"JMQwwCgYDVQQKDANBUk0xHDAaBgNVBAMME21iZWQtY29ubmVjdG9yLTIwMTgwHh\r\n"
"cNMTcwODMxMTQzMjQ1WhcNMTgxMjMxMDYwMDAwWjCBoTFSMFAGA1UEAxNJZDMyY\r\n"
"mFmNjEtNDg0NS00YWU3LWJmMGMtM2IwYjJjOGRiMmU0L2U3ZWYyOWUwLTk0NTgt\r\n"
"NDdhZi04YzJmLWMzZmQ4Zjg3NjgyYzEMMAoGA1UECxMDQVJNMRIwEAYDVQQKEwl\r\n"
"tYmVkIHVzZXIxDTALBgNVBAcTBE91bHUxDTALBgNVBAgTBE91bHUxCzAJBgNVBA\r\n"
"YTAkZJMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEgfa9hn/bB5F5CZIMq9RWV\r\n"
"4d4NJxAOt6pGKsggk3iT4rqwCyHy/ZJHlgAaTyCSM7PH9/Qr3pMyiVz4k78yMA2\r\n"
"5zAMBggqhkjOPQQDAgUAA0gAMEUCIQCxoKq/jctiOg4AvH9Sa7+rLiK5cyXJ0Jb\r\n"
"+zKL1kxVzhgIgVlA15FXiXjptmxF0BAhoK6BJb6Dcdd6jUQzKYaatLhk=\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t KEY[] = "-----BEGIN PRIVATE KEY-----\r\n"
"MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgTO8315S8/MYtMnwO\r\n"
"HnfnzQrfvvNHzZNLt1ej6n+6AZWhRANCAASB9r2Gf9sHkXkJkgyr1FZXh3g0nEA6\r\n"
"3qkYqyCCTeJPiurALIfL9kkeWABpPIJIzs8f39CvekzKJXPiTvzIwDbn\r\n"
"-----END PRIVATE KEY-----\r\n";
 
#endif //__SECURITY_H__
