/*
 * Copyright (c) 2015 ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef __SECURITY_H__
#define __SECURITY_H__
 
#include <inttypes.h>
 
#define MBED_DOMAIN "d32baf61-4845-4ae7-bf0c-3b0b2c8db2e4"
#define MBED_ENDPOINT_NAME "f088616b-a80c-4c31-b12d-9cd9a8b05e91"
 
const uint8_t SERVER_CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBmDCCAT6gAwIBAgIEVUCA0jAKBggqhkjOPQQDAjBLMQswCQYDVQQGEwJGSTEN\r\n"
"MAsGA1UEBwwET3VsdTEMMAoGA1UECgwDQVJNMQwwCgYDVQQLDANJb1QxETAPBgNV\r\n"
"BAMMCEFSTSBtYmVkMB4XDTE1MDQyOTA2NTc0OFoXDTE4MDQyOTA2NTc0OFowSzEL\r\n"
"MAkGA1UEBhMCRkkxDTALBgNVBAcMBE91bHUxDDAKBgNVBAoMA0FSTTEMMAoGA1UE\r\n"
"CwwDSW9UMREwDwYDVQQDDAhBUk0gbWJlZDBZMBMGByqGSM49AgEGCCqGSM49AwEH\r\n"
"A0IABLuAyLSk0mA3awgFR5mw2RHth47tRUO44q/RdzFZnLsAsd18Esxd5LCpcT9w\r\n"
"0tvNfBv4xJxGw0wcYrPDDb8/rjujEDAOMAwGA1UdEwQFMAMBAf8wCgYIKoZIzj0E\r\n"
"AwIDSAAwRQIhAPAonEAkwixlJiyYRQQWpXtkMZax+VlEiS201BG0PpAzAiBh2RsD\r\n"
"NxLKWwf4O7D6JasGBYf9+ZLwl0iaRjTjytO+Kw==\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBzzCCAXOgAwIBAgIEZ0aGsTAMBggqhkjOPQQDAgUAMDkxCzAJBgNVBAYTAkZ\r\n"
"JMQwwCgYDVQQKDANBUk0xHDAaBgNVBAMME21iZWQtY29ubmVjdG9yLTIwMTgwHh\r\n"
"cNMTcwODMxMTQzMTM0WhcNMTgxMjMxMDYwMDAwWjCBoTFSMFAGA1UEAxNJZDMyY\r\n"
"mFmNjEtNDg0NS00YWU3LWJmMGMtM2IwYjJjOGRiMmU0L2YwODg2MTZiLWE4MGMt\r\n"
"NGMzMS1iMTJkLTljZDlhOGIwNWU5MTEMMAoGA1UECxMDQVJNMRIwEAYDVQQKEwl\r\n"
"tYmVkIHVzZXIxDTALBgNVBAcTBE91bHUxDTALBgNVBAgTBE91bHUxCzAJBgNVBA\r\n"
"YTAkZJMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEfpWCLdkhkV2Xdqo05ixTL\r\n"
"LGcgSsrMzdR1cyYxceAdheKNQBY+sxIFsGgCtkYXMVIWOdj9BZ+SR58Q3BgzuSP\r\n"
"0jAMBggqhkjOPQQDAgUAA0gAMEUCIQCE4Ywb6gPfr/6oLCpFU2/q+lmu1Rks85g\r\n"
"o1LZulaZ17AIgEhbZesGCGOSIbjljsu149mqUYnoWc6sVgFgFR+6Z6to=\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t KEY[] = "-----BEGIN PRIVATE KEY-----\r\n"
"MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgOyg4cHaDd+ijNQCt\r\n"
"Dkh75u7MvTjdf3xsimKDTVTxiv6hRANCAAR+lYIt2SGRXZd2qjTmLFMssZyBKysz\r\n"
"N1HVzJjFx4B2F4o1AFj6zEgWwaAK2RhcxUhY52P0Fn5JHnxDcGDO5I/S\r\n"
"-----END PRIVATE KEY-----\r\n";
 
#endif //__SECURITY_H__
