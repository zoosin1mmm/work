/*
 * Copyright (c) 2015 ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef __SECURITY_H__
#define __SECURITY_H__
 
#include <inttypes.h>
 
#define MBED_DOMAIN "d32baf61-4845-4ae7-bf0c-3b0b2c8db2e4"
#define MBED_ENDPOINT_NAME "415a21a8-8cca-42ed-8463-24d7e980b55c"
 
const uint8_t SERVER_CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBmDCCAT6gAwIBAgIEVUCA0jAKBggqhkjOPQQDAjBLMQswCQYDVQQGEwJGSTEN\r\n"
"MAsGA1UEBwwET3VsdTEMMAoGA1UECgwDQVJNMQwwCgYDVQQLDANJb1QxETAPBgNV\r\n"
"BAMMCEFSTSBtYmVkMB4XDTE1MDQyOTA2NTc0OFoXDTE4MDQyOTA2NTc0OFowSzEL\r\n"
"MAkGA1UEBhMCRkkxDTALBgNVBAcMBE91bHUxDDAKBgNVBAoMA0FSTTEMMAoGA1UE\r\n"
"CwwDSW9UMREwDwYDVQQDDAhBUk0gbWJlZDBZMBMGByqGSM49AgEGCCqGSM49AwEH\r\n"
"A0IABLuAyLSk0mA3awgFR5mw2RHth47tRUO44q/RdzFZnLsAsd18Esxd5LCpcT9w\r\n"
"0tvNfBv4xJxGw0wcYrPDDb8/rjujEDAOMAwGA1UdEwQFMAMBAf8wCgYIKoZIzj0E\r\n"
"AwIDSAAwRQIhAPAonEAkwixlJiyYRQQWpXtkMZax+VlEiS201BG0PpAzAiBh2RsD\r\n"
"NxLKWwf4O7D6JasGBYf9+ZLwl0iaRjTjytO+Kw==\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIB0DCCAXOgAwIBAgIEPqTRmDAMBggqhkjOPQQDAgUAMDkxCzAJBgNVBAYTAkZ\r\n"
"JMQwwCgYDVQQKDANBUk0xHDAaBgNVBAMME21iZWQtY29ubmVjdG9yLTIwMTgwHh\r\n"
"cNMTcwODMxMTQzNzI1WhcNMTgxMjMxMDYwMDAwWjCBoTFSMFAGA1UEAxNJZDMyY\r\n"
"mFmNjEtNDg0NS00YWU3LWJmMGMtM2IwYjJjOGRiMmU0LzQxNWEyMWE4LThjY2Et\r\n"
"NDJlZC04NDYzLTI0ZDdlOTgwYjU1YzEMMAoGA1UECxMDQVJNMRIwEAYDVQQKEwl\r\n"
"tYmVkIHVzZXIxDTALBgNVBAcTBE91bHUxDTALBgNVBAgTBE91bHUxCzAJBgNVBA\r\n"
"YTAkZJMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEcONBZHf8k6+ipPdSIxkFx\r\n"
"Exxw1eZXUNPoxBDfkENcKWSbisfY3E/6yLmnSvoAeshkytul14KbAhSq51FVD1Q\r\n"
"TjAMBggqhkjOPQQDAgUAA0kAMEYCIQCwSMre1uRj2S0zfCEhEnlEtpwY3+pCb7e\r\n"
"POVqPzJkofwIhAL1NF8X+TcnHxEmFcvzj0JTpqziVYk3y8zodkUHDFx36\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t KEY[] = "-----BEGIN PRIVATE KEY-----\r\n"
"MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgp+00R1eFZaq1acdJ\r\n"
"U7MI9Txh+wipyj6UBlkz5qPT+W+hRANCAARw40Fkd/yTr6Kk91IjGQXETHHDV5ld\r\n"
"Q0+jEEN+QQ1wpZJuKx9jcT/rIuadK+gB6yGTK26XXgpsCFKrnUVUPVBO\r\n"
"-----END PRIVATE KEY-----\r\n";
 
#endif //__SECURITY_H__
