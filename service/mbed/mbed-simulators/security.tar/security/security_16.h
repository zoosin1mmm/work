/*
 * Copyright (c) 2015 ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef __SECURITY_H__
#define __SECURITY_H__
 
#include <inttypes.h>
 
#define MBED_DOMAIN "d32baf61-4845-4ae7-bf0c-3b0b2c8db2e4"
#define MBED_ENDPOINT_NAME "06deb685-135b-4b3d-a5bf-8f773b8b613e"
 
const uint8_t SERVER_CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBmDCCAT6gAwIBAgIEVUCA0jAKBggqhkjOPQQDAjBLMQswCQYDVQQGEwJGSTEN\r\n"
"MAsGA1UEBwwET3VsdTEMMAoGA1UECgwDQVJNMQwwCgYDVQQLDANJb1QxETAPBgNV\r\n"
"BAMMCEFSTSBtYmVkMB4XDTE1MDQyOTA2NTc0OFoXDTE4MDQyOTA2NTc0OFowSzEL\r\n"
"MAkGA1UEBhMCRkkxDTALBgNVBAcMBE91bHUxDDAKBgNVBAoMA0FSTTEMMAoGA1UE\r\n"
"CwwDSW9UMREwDwYDVQQDDAhBUk0gbWJlZDBZMBMGByqGSM49AgEGCCqGSM49AwEH\r\n"
"A0IABLuAyLSk0mA3awgFR5mw2RHth47tRUO44q/RdzFZnLsAsd18Esxd5LCpcT9w\r\n"
"0tvNfBv4xJxGw0wcYrPDDb8/rjujEDAOMAwGA1UdEwQFMAMBAf8wCgYIKoZIzj0E\r\n"
"AwIDSAAwRQIhAPAonEAkwixlJiyYRQQWpXtkMZax+VlEiS201BG0PpAzAiBh2RsD\r\n"
"NxLKWwf4O7D6JasGBYf9+ZLwl0iaRjTjytO+Kw==\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBzzCCAXOgAwIBAgIEIWUC9zAMBggqhkjOPQQDAgUAMDkxCzAJBgNVBAYTAkZ\r\n"
"JMQwwCgYDVQQKDANBUk0xHDAaBgNVBAMME21iZWQtY29ubmVjdG9yLTIwMTgwHh\r\n"
"cNMTcwODMxMTQzNjM1WhcNMTgxMjMxMDYwMDAwWjCBoTFSMFAGA1UEAxNJZDMyY\r\n"
"mFmNjEtNDg0NS00YWU3LWJmMGMtM2IwYjJjOGRiMmU0LzA2ZGViNjg1LTEzNWIt\r\n"
"NGIzZC1hNWJmLThmNzczYjhiNjEzZTEMMAoGA1UECxMDQVJNMRIwEAYDVQQKEwl\r\n"
"tYmVkIHVzZXIxDTALBgNVBAcTBE91bHUxDTALBgNVBAgTBE91bHUxCzAJBgNVBA\r\n"
"YTAkZJMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEdW9JC3XjG1+az+/ZX8qPJ\r\n"
"qAKXH0drFRM9KVPH2TMSJGWX+pHWMSAjyca24h25BD1AenPWJ01zo9zkc0RXFow\r\n"
"VTAMBggqhkjOPQQDAgUAA0gAMEUCIFmRJAh9UpdndhKR41zYO/bm50Z3GUfzLTu\r\n"
"eVPkXt696AiEA/T709L5bny48KNE2UMeWFXMEJ3fmuQIY9xwCHzqUsmM=\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t KEY[] = "-----BEGIN PRIVATE KEY-----\r\n"
"MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgJHt+WXWua0jvHW25\r\n"
"SHOmGNT6ynzA9XxdUJVVh7Cs+AShRANCAAR1b0kLdeMbX5rP79lfyo8moApcfR2s\r\n"
"VEz0pU8fZMxIkZZf6kdYxICPJxrbiHbkEPUB6c9YnTXOj3ORzRFcWjBV\r\n"
"-----END PRIVATE KEY-----\r\n";
 
#endif //__SECURITY_H__
