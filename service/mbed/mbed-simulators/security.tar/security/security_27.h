/*
 * Copyright (c) 2015 ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef __SECURITY_H__
#define __SECURITY_H__
 
#include <inttypes.h>
 
#define MBED_DOMAIN "d32baf61-4845-4ae7-bf0c-3b0b2c8db2e4"
#define MBED_ENDPOINT_NAME "e3fac4ea-e416-4f4b-bb38-740053171f87"
 
const uint8_t SERVER_CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBmDCCAT6gAwIBAgIEVUCA0jAKBggqhkjOPQQDAjBLMQswCQYDVQQGEwJGSTEN\r\n"
"MAsGA1UEBwwET3VsdTEMMAoGA1UECgwDQVJNMQwwCgYDVQQLDANJb1QxETAPBgNV\r\n"
"BAMMCEFSTSBtYmVkMB4XDTE1MDQyOTA2NTc0OFoXDTE4MDQyOTA2NTc0OFowSzEL\r\n"
"MAkGA1UEBhMCRkkxDTALBgNVBAcMBE91bHUxDDAKBgNVBAoMA0FSTTEMMAoGA1UE\r\n"
"CwwDSW9UMREwDwYDVQQDDAhBUk0gbWJlZDBZMBMGByqGSM49AgEGCCqGSM49AwEH\r\n"
"A0IABLuAyLSk0mA3awgFR5mw2RHth47tRUO44q/RdzFZnLsAsd18Esxd5LCpcT9w\r\n"
"0tvNfBv4xJxGw0wcYrPDDb8/rjujEDAOMAwGA1UdEwQFMAMBAf8wCgYIKoZIzj0E\r\n"
"AwIDSAAwRQIhAPAonEAkwixlJiyYRQQWpXtkMZax+VlEiS201BG0PpAzAiBh2RsD\r\n"
"NxLKWwf4O7D6JasGBYf9+ZLwl0iaRjTjytO+Kw==\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t CERT[] = "-----BEGIN CERTIFICATE-----\r\n"
"MIIBzzCCAXOgAwIBAgIEfpiVdTAMBggqhkjOPQQDAgUAMDkxCzAJBgNVBAYTAkZ\r\n"
"JMQwwCgYDVQQKDANBUk0xHDAaBgNVBAMME21iZWQtY29ubmVjdG9yLTIwMTgwHh\r\n"
"cNMTcwODMxMTQzNDE2WhcNMTgxMjMxMDYwMDAwWjCBoTFSMFAGA1UEAxNJZDMyY\r\n"
"mFmNjEtNDg0NS00YWU3LWJmMGMtM2IwYjJjOGRiMmU0L2UzZmFjNGVhLWU0MTYt\r\n"
"NGY0Yi1iYjM4LTc0MDA1MzE3MWY4NzEMMAoGA1UECxMDQVJNMRIwEAYDVQQKEwl\r\n"
"tYmVkIHVzZXIxDTALBgNVBAcTBE91bHUxDTALBgNVBAgTBE91bHUxCzAJBgNVBA\r\n"
"YTAkZJMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE/t5v4p3RhmzGEE9HK5huH\r\n"
"z8Q+Ks9KxLoR4VAgjhRSo4+D7jDtLJhQ96c/kNEuOV69zVjlVAkdP88RJHyufwI\r\n"
"xDAMBggqhkjOPQQDAgUAA0gAMEUCIBx7Y7M93P3KFaJEMGbgvEzvbNPoY53TK74\r\n"
"CH7VI7I3HAiEAwshl7MuUDtNQmdO3Ax5tc1WnUi3mK3hCGpTmZmRXq94=\r\n"
"-----END CERTIFICATE-----\r\n";
 
const uint8_t KEY[] = "-----BEGIN PRIVATE KEY-----\r\n"
"MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQguIe6/Id9T+ytTWpe\r\n"
"pHtJYPo5A500QfhiGMu66UVv0kuhRANCAAT+3m/indGGbMYQT0crmG4fPxD4qz0r\r\n"
"EuhHhUCCOFFKjj4PuMO0smFD3pz+Q0S45Xr3NWOVUCR0/zxEkfK5/AjE\r\n"
"-----END PRIVATE KEY-----\r\n";
 
#endif //__SECURITY_H__
